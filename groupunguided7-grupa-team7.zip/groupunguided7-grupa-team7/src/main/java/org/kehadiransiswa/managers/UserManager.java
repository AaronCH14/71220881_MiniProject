package org.kehadiransiswa.managers;

import org.kehadiransiswa.data.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserManager {
    List<User> users;

    public UserManager() {
        users = new ArrayList<>();
    }

    public boolean registerUser(String username, String password, String email, String role) {
        User newUser = new User(users.size()+1, username, password, email, role);
        if(users.isEmpty()){
            users.add(newUser);
            return true;
        }
        for (User user : users) {
            if (!user.getEmail().equalsIgnoreCase(newUser.getEmail())) {
                users.add(newUser);
                return true;
            }
        }

        return false;
    }

    public boolean updateProfile(int id, String username, String password, String email, String role) {
        User newUser = new User(id, username, password, email, role);
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == newUser.getId()) {
                users.set(i, newUser);
                return true;
            }
        }
        return false;
    }


    public List<User> getAllUser() {
        return users;
    }
}
