package org.kehadiransiswa.managers;

import org.kehadiransiswa.data.Course;
import org.kehadiransiswa.data.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CourseManager {
    List<Course> courses = new ArrayList<>();

    public CourseManager() {
    }

    // Add methods for course management (create, edit, delete)
    public boolean addCourse(String title, String description) {
        Course newCourse = new Course(courses.size() + 1, title, description);
        if (!courses.contains(newCourse)) {
            courses.add(newCourse);
            return true;
        }
        return false;
    }
    public class AttendanceManager {
        public boolean addCourse(int classId, int userId, String status) {
            String sql = "INSERT INTO AttendanceRecords (class_id, user_id, status) VALUES (?, ?, ?)";

            try (Connection connection = DBConnectionManager.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

                preparedStatement.setInt(1, classId);
                preparedStatement.setInt(2, userId);
                preparedStatement.setString(3, status);

                int rowsAffected = preparedStatement.executeUpdate();
                return rowsAffected > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }
    }

    public boolean editCourse(int courseId, String newTitle, String newDescription) {
        Course newCourse = new Course(courseId, newTitle, newDescription);
        for (int i = 0; i < courses.size(); i++) {
            if (courses.get(i).getId() == courseId) {
                courses.set(i, newCourse);
            }
        }
        return false;

    }

    public boolean deleteCourse(int courseId) {
        int indexToDelete = -1;
        for (int i = 0; i < courses.size(); i++) {
            if (courses.get(i).getId() == courseId) {
                indexToDelete = i;
            }
        }
        if (indexToDelete > 0) {
            courses.remove(indexToDelete);
        }
        return false;

    }

    public List<Course> getAllCourses() {
        return courses;
    }
}
